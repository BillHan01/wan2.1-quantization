from .timer import gpu_timer_decorator
